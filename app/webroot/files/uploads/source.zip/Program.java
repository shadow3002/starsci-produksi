import java.io.IOException;
import java.util.* ;
public class Program {
    
	public static void main(String args[]) throws IOException {   
        String input =   "int x ;\n"
                        +"x = 2 ;\n"
                        +"if ( x < 3 ) then \n"
                        +"  begin\n"
                        +"      \\\\comentario ;\n"
                        +"      x = 4 ;\n"
                        +"  end\n" ;
        
        FileToString fts = new FileToString() ;
        // descomentar para que lea del archivo
        // input = fts.convert("file.txt") ;
        SymbolTable st = new SymbolTable() ;
        
        LexicalAnalyzer lexical = new LexicalAnalyzer(Automat.generateAutomat(), st) ;
		Parser parser = new Parser(input, lexical, st) ;
        System.out.println(parser.yyparse()) ;
		

        System.out.println( lexical.getOutput() );
	}
	
	public static int toInteger( String token ) {
	    Map<String, Integer> hm = new HashMap<String, Integer>();
//	    hm.put("then", Parse.THEN) ;
	    
		return hm.get( token ) ;
		
	}
	
}