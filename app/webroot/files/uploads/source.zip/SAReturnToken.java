import java.util.*;
public class SAReturnToken implements SemanticAction {
    
    private String token = "" ;
    
 //   private String [] rw  = new String [] {"if", "then", "else", "begin", "end", "print", "function", "return", "int", "for"} ;

 //   private ArrayList<String> reservedWords = new ArrayList<String>(Arrays.asList(rw)) ;

    public SAReturnToken(String t) {
        token = t ;
    }
    
    public void execute( LexicalAnalyzer analyzer ) {
      //  System.out.print(token);
        String symbol = analyzer.getSymbol() ;
        if ( analyzer.isReservedWord( symbol ) ) {
            analyzer.updateToken(symbol.toUpperCase()); 
            analyzer.addOutput( "Reserved Word: '" + symbol + "'" ) ;
        } else {
            analyzer.updateToken(token);
            if ( !token.equals(symbol) || token.equals("ID") ) {
                analyzer.addOutput( token + ": '"+ symbol + "'" ) ;
            } else {
                analyzer.addOutput( symbol ) ;
                   
            }
            
        } 
        //TODO
        //analyzer.updateSymbolsTable() ;
    }

}