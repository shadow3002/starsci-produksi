import java.util.* ;
public class SAComposite implements SemanticAction {
    
    private Vector<SemanticAction> saList = new Vector<SemanticAction>() ;
    
    public SAComposite() {}
    
    public SAComposite( Vector<SemanticAction> list ) {
        saList = list ;
    }

    public void execute( LexicalAnalyzer analyzer ) {
        for ( SemanticAction sa : saList ) {
            sa.execute( analyzer ) ;
        }
    }
    
    public void add( SemanticAction sa ) {
        saList.add(sa) ;
    }
}