public class SANewLine implements SemanticAction {

    public SANewLine() {}

    public void execute( LexicalAnalyzer analyzer ) {
       analyzer.incCurrentLine() ;
    }
}