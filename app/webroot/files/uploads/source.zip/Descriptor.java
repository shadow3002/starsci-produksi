public class Descriptor {
    private Integer token = null ;
    private String type = null ;

    
    public Descriptor() {} 

    public Descriptor( Integer to, String ty ) {
        token = to ; 
        type = ty ;
    } 
    
    public Integer getToken() {
        return token ;
    }
    public String getType() {
        return type ;
    }
    
    public void setToken( Integer t ) {
        token = t;
    }
    public void setType( String t ) {
        type = t ;
    }
}
