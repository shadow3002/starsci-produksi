import java.util.* ;

public class Automat {

    private String currentSt = State.ST_INIT ;

    //State transition map
    // Structure HM : key="st-input", value={output, SemanticAtion}    
    private Map<String, Object> hm = new HashMap<String, Object>();

    private char mappingChar(char ch) {       
        // TODO
        // ERROR : unmappable character for encoding ASCII
         if ( 48 <= (int)ch  && (int)ch <= 57  ) {
            return 'd' ; // d from digit
         } else if ( (65<=(int)ch && (int)ch<=90) || (97<=(int)ch && (int)ch<=122)) {
            return 'l' ; // l from letter
         } else {
            return ch ;
         }
    }
    
    public Automat() {
        //TODO
    }

    
    public void addTransition(String st, char [] input, String nextSt, Object output){       
        for ( int i = 0; i < input.length; i++) {
            this.addTransition(st, input[i], nextSt, output) ;
        }
    }

    
    public void addTransition(String st, char input, String nextSt, Object output){       
        Pair<String, Object> p = new Pair<String, Object>(nextSt, output) ;
        hm.put(st + input, p) ;
    }

	public Object next(char input) {
        String key = this.currentSt + mappingChar( input ) ; 
		Pair<String, Object> value = (Pair<String, Object>) hm.get(key);
        
        if ( value != null ) {
            this.currentSt = value.getFirst() ;        	
            return value.getSecond() ;
        } else {
    		this.currentSt = State.ST_FINAL ;
    		return null ;
    	}

        
    }

    public boolean finalState() {
        return currentSt == State.ST_FINAL ;
    }
    
    public void reset() {
        currentSt = State.ST_INIT ;
    }
    
    public static Automat generateAutomat() {
        Automat automat = new Automat() ;

        //GENERICAL Semantic Actions
        SemanticAction saNull = new SANull() ;        
        SemanticAction saGoBack = new SAGoBack() ;        
        SANewLine saNewLine = new SANewLine() ;
        SemanticAction saCancelToken = new SACancelToken() ;
        SemanticAction saSkipPrevChar = new SASkipPrevChar() ;
        SemanticAction saCheckRange = new SACheckRange() ;
        SemanticAction saFilterId = new SAFilterId() ;
        
 
        char [] simbols = {'+', '-', '*', '/','=','>','<','(',')',',',';','!','"', '\n', ' '} ; // C-L-D

        
        
        // ************* IDENTIFIERS ************ //      
        SemanticAction saIdReturnToken = new SAReturnToken(Token.TK_ID) ;  
        SAComposite saId = new SAComposite() ;
        saId.add( saGoBack ) ;        
        saId.add( saFilterId ) ;
        saId.add( saIdReturnToken ) ;  
        
        automat.addTransition(State.ST_INIT,
                              'l', 
                              State.ST_ID,
                              saNull ) ;    

        automat.addTransition(State.ST_ID, 
                              new char [] {'l', 'd'}, 
                              State.ST_ID, 
                              saNull ) ;
        
        automat.addTransition(State.ST_ID, 
                              simbols, 
                              State.ST_FINAL, 
                              saId ) ;
        
        
        
        
        
        // ************* CONSTANTS ************** //
        SemanticAction saConstReturnToken = new SAReturnToken(Token.TK_CONST) ;        
        SAComposite saConstComposite = new SAComposite() ;
        saConstComposite.add( saGoBack ) ;        
        saConstComposite.add( saCheckRange ) ;        
        
        saConstComposite.add( saConstReturnToken ) ;        

        
        automat.addTransition(State.ST_INIT, 
                              'd', 
                              State.ST_CONST, 
                              saNull ) ;    
        
        automat.addTransition(State.ST_CONST,
                              'd', 
                              State.ST_CONST, 
                              saNull ) ;
     
        automat.addTransition(State.ST_CONST, 
                              new char [] {'l','+', '-', '*', '/','=','>','<','(',')',',',';','!','"', ' ', '\n'}, // C-D 
                              State.ST_FINAL, 
                              saConstComposite ) ;
        
        
        
        
        
        
        // ************** COMMENT ************** //  
        // NOTE: '\\' represents a single '\'
        SAComposite saComment = new SAComposite() ;
        saComment.add(saNewLine) ;
        saComment.add(saCancelToken) ;
        
        automat.addTransition(State.ST_INIT, 
                              '\\', 
                              State.ST_POT_COMMENT, 
                              saNull ) ;    
               
        automat.addTransition(State.ST_POT_COMMENT, 
                              '\\',
                              State.ST_COMMENT, 
                              saNull ) ;

        automat.addTransition(State.ST_COMMENT, 
                              new char [] {'l', 'd' ,'+', '-', '*', '/','=','>','<','(',')',',',';','!','"', '\\', ' '}, // C-{\n}
                              State.ST_COMMENT, 
                              saNull ) ;
        
        automat.addTransition(State.ST_COMMENT, 
                              '\n', 
                              State.ST_INIT, 
                              saComment ) ;
        
        
        
        
        
        
        // ************* NULL CHARS {TAB, BLANK} ************ //
        automat.addTransition(State.ST_INIT, 
                              new char [] {' ', '\t'}, 
                              State.ST_INIT, 
                              saCancelToken ) ;
        
        
        
        
        // ************* NEW LINE  ************ //      
        SAComposite saNL = new SAComposite() ;
        saNL.add(saNewLine) ;
        saNL.add(saCancelToken) ;
        automat.addTransition(State.ST_INIT, 
                              '\n', 
                              State.ST_INIT, 
                              saNL ) ;

        
        
        
        // ************* = & == ************ //
        SemanticAction saRTAssign = new SAReturnToken(Token.TK_ASSIGN) ;        
        SAComposite saAssign = new SAComposite() ;
        saAssign.add( saGoBack ) ;        
        saAssign.add( saRTAssign ) ;        

        char [] c_eq = {'l', 'd', '+', '-', '*', '/','>','<','(',')',',',';','!','"', '\n', ' '} ; // C-'='
 
        automat.addTransition(State.ST_INIT,
                              '=', 
                              State.ST_POT_ASSIGN, 
                              saNull ) ;
        
        automat.addTransition(State.ST_POT_ASSIGN, 
                              c_eq, 
                              State.ST_FINAL, 
                              saAssign ) ;

        automat.addTransition(State.ST_POT_ASSIGN, 
                              c_eq, 
                              State.ST_FINAL, 
                              saAssign ) ;
       
        SemanticAction saRTEqComp = new SAReturnToken(Token.TK_EQUAL_COMP) ;        
        SAComposite saEqComp = new SAComposite() ;
        saEqComp.add( saGoBack ) ;        
        saEqComp.add( saRTEqComp ) ;        
        
        automat.addTransition(State.ST_POT_ASSIGN, '=', State.ST_FINAL, saEqComp ) ;
        
        
        
        

        // ************* != ************ // distinct

        SemanticAction saDistinct = new SAReturnToken(Token.TK_DISTINCT) ;        
        
        automat.addTransition(State.ST_INIT, 
                              '!', 
                              State.ST_DISTINCT, 
                              saNull ) ;
        
        automat.addTransition(State.ST_DISTINCT, 
                              '=', 
                              State.ST_FINAL, 
                              saDistinct ) ;
        
        
        
        
        // ************* > & >= ************ // greater than
        SAComposite saGreater = new SAComposite() ;        
        SemanticAction saRTGreater = new SAReturnToken(Token.TK_GREATER_THAN) ;
        saGreater.add(saGoBack);
        saGreater.add(saRTGreater);
        
        SemanticAction saGreaterEq = new SAReturnToken(Token.TK_GREATER_EQ) ;        
        
        automat.addTransition(State.ST_INIT, 
                              '>', 
                              State.ST_GREATER, 
                              saNull ) ;

        automat.addTransition(State.ST_GREATER, 
                              '=', 
                              State.ST_FINAL, 
                              saGreaterEq ) ;
        
        automat.addTransition(State.ST_GREATER, 
                              c_eq, 
                              State.ST_FINAL, 
                              saGreater ) ;
        

        // ************* < & <= ************ // less than
        SAComposite saLess = new SAComposite() ;        
        SemanticAction saRTLess = new SAReturnToken(Token.TK_LESS_THAN) ;
        
        saLess.add(saGoBack);
        saLess.add(saRTLess);
        
        SemanticAction saLessEq = new SAReturnToken(Token.TK_LESS_EQ) ;        
        
        automat.addTransition(State.ST_INIT, 
                              '<', 
                              State.ST_LESS, 
                              saNull ) ;

        automat.addTransition(State.ST_LESS, 
                              '=', 
                              State.ST_FINAL, 
                              saLessEq ) ;
        
        automat.addTransition(State.ST_LESS,
                              c_eq, 
                              State.ST_FINAL, 
                              saLess ) ;
        
        // ************* + - * / ( ) , ; ************ // 
        SemanticAction saAdd = new SAReturnToken(Token.TK_ADD) ;  
        automat.addTransition(State.ST_INIT, '+', State.ST_FINAL, saAdd ) ;

        SemanticAction saSub = new SAReturnToken(Token.TK_SUB) ;  
        automat.addTransition(State.ST_INIT, '-', State.ST_FINAL, saSub ) ;
        
        SemanticAction saMult = new SAReturnToken(Token.TK_MULT) ;  
        automat.addTransition(State.ST_INIT, '*', State.ST_FINAL, saMult ) ;

        SemanticAction saDiv = new SAReturnToken(Token.TK_DIV) ;  
        automat.addTransition(State.ST_INIT, '/', State.ST_FINAL, saDiv ) ;
        
        SemanticAction saOpenedPar = new SAReturnToken(Token.TK_OPENED_PAR) ;  
        automat.addTransition(State.ST_INIT, '(', State.ST_FINAL, saOpenedPar ) ;
        
        SemanticAction saClosedPar = new SAReturnToken(Token.TK_CLOSED_PAR) ;  
        automat.addTransition(State.ST_INIT, ')', State.ST_FINAL, saClosedPar ) ;
        
        SemanticAction saComa = new SAReturnToken(Token.TK_COMA) ;  
        automat.addTransition(State.ST_INIT, ',', State.ST_FINAL, saComa ) ;
        
        SemanticAction saSemicolon = new SAReturnToken(Token.TK_SEMICOLON) ;  
        automat.addTransition(State.ST_INIT, ';', State.ST_FINAL, saSemicolon ) ;
        
        
        
        
        // String multiline
        SemanticAction saString = new SAReturnToken(Token.TK_STRING) ;        
        SAComposite saStringNL = new SAComposite() ;
        saStringNL.add(saNewLine) ;
        saStringNL.add(saSkipPrevChar) ;
        
        automat.addTransition(State.ST_INIT, '"', State.ST_STRING, saNull ) ;
     
        char [] c_mul = {'l', 'd', '-', '*', '/','>','<','(',')',',',';','!', ' ', '='} ; // C - " - + - \n

        automat.addTransition(State.ST_STRING, 
                              c_mul, 
                              State.ST_STRING, 
                              saNull ) ; // C - " - + - \n
        
        automat.addTransition(State.ST_STRING, 
                              '+', 
                              State.ST_POT_ENDSTRING, 
                              saNull ) ; //saCancelChar
        
        automat.addTransition(State.ST_STRING, 
                              '"', 
                              State.ST_FINAL, 
                              saString ) ; 

        automat.addTransition(State.ST_POT_ENDSTRING, 
                              '+', 
                              State.ST_POT_ENDSTRING, 
                              saNull ) ; 
        
        automat.addTransition(State.ST_POT_ENDSTRING, 
                              '\n', 
                              State.ST_STRING, 
                              saStringNL ) ;  //saCancelChar
        
        automat.addTransition(State.ST_POT_ENDSTRING, 
                              c_mul, 
                              State.ST_STRING, 
                              saNull ) ; // C - " - \n
        
        automat.addTransition(State.ST_POT_ENDSTRING, 
                              '"', 
                              State.ST_FINAL, 
                              saString ) ; 

        return automat ;

    }

    
}