
public class SAGoBack implements SemanticAction {

    public SAGoBack() {}

    public void execute( LexicalAnalyzer analyzer ) {
        analyzer.goBack() ;
    }
}
