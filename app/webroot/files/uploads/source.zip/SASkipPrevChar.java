public class SASkipPrevChar implements SemanticAction {

    public SASkipPrevChar() {}

    public void execute( LexicalAnalyzer analyzer ) {
        analyzer.skipPrevChar() ;
    }
}