// Constants declaration
// TODO
public class State {

    final static String ST_FINAL = "final" ;
    final static String ST_ID = "id" ;
    final static String ST_INIT = "init" ;
    final static String ST_CONST = "const" ;
    final static String ST_POT_COMMENT = "potential_comment" ;
    final static String ST_COMMENT = "comment" ;
    final static String ST_POT_ASSIGN = "potential_assign" ;
    final static String ST_ASSIGN = "assign" ;
    final static String ST_EQUAL = "equal" ;
    final static String ST_DISTINCT = "distinct" ;
    final static String ST_GREATER = "greater" ;
    final static String ST_LESS = "less" ;
//STRING STATES
    final static String ST_STRING = "string" ;
    final static String ST_STRING_NL = "newline_string" ;
    final static String ST_POT_ENDSTRING = "+" ;
    
    
    
    
}