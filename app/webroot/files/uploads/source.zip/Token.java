
public class Token {
    final static String TK_ID = "ID" ;
    final static String TK_CONST = "CONST" ;
    final static String TK_ASSIGN = "=" ;
    final static String TK_EQUAL_COMP = "==" ;
    final static String TK_DISTINCT = "!=" ;
    final static String TK_GREATER_THAN = ">" ;
    final static String TK_GREATER_EQ = ">=" ;
    final static String TK_LESS_THAN = "<" ;
    final static String TK_LESS_EQ = "<=" ;
    final static String TK_ADD = "+" ;
    final static String TK_SUB = "-" ;
    final static String TK_MULT = "*" ;
    final static String TK_DIV = "/" ;
    final static String TK_OPENED_PAR = "(" ;
    final static String TK_CLOSED_PAR = ")" ;
    final static String TK_COMA = "," ;
    final static String TK_SEMICOLON = ";" ;
    final static String TK_NULL = "" ;
    final static String TK_STRING = "STRING" ;
    
    


}
