// OMITE EL TOKEN
public class SACancelToken implements SemanticAction {

    public SACancelToken() {}

    public void execute( LexicalAnalyzer analyzer ) {
        analyzer.resetSymbol() ;
    }
}