public class SACheckRange implements SemanticAction {

    private static final Integer CONST_MAX = 32768 ;
    public SACheckRange() {}

    public void execute( LexicalAnalyzer analyzer ) {           
        if ( Integer.parseInt(analyzer.getSymbol()) > CONST_MAX ) {
            analyzer.reportError("ERROR: Constant "+ analyzer.getSymbol() +" out of range") ;
        }
    }
}