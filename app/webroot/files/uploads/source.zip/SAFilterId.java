public class SAFilterId implements SemanticAction {

    public static final Integer ID_MAX = 15 ;
    
    public SAFilterId() {}

    public void execute( LexicalAnalyzer analyzer ) {
        String symbol = analyzer.getSymbol() ;
        if ( symbol.length() > ID_MAX ) {
            String truncated = symbol.substring( 0, ID_MAX ) ;
            analyzer.reportError("WARNING: Identifier \'" + symbol + "\' is too long, truncated to \'" + truncated + "\'.") ;
            analyzer.setSymbol( truncated ) ;
        }
        
         
    }
}