import java.util.* ;
public class SymbolTable {
    private Map<String, String> hash = new HashMap<String, String> () ;  
        
    public SymbolTable() {
        hash.put("if", "ReservedWord");
        hash.put("then", "ReservedWord") ;
        hash.put("else", "ReservedWord") ;
        hash.put("begin",  "ReservedWord") ;
        hash.put("end", "ReservedWord") ;
        hash.put("print", "ReservedWord") ;
        hash.put("function", "ReservedWord") ;
        hash.put("return", "ReservedWord") ;
        hash.put("int", "ReservedWord") ;
        hash.put("for", "ReservedWord") ;
    }
    
    public String get( String symbol ) {
        return hash.get(symbol) ;
    }
    
    public boolean put( String key, String value ) {
        if ( hash.containsKey(key) ) {
            return false ;
        } else {
            hash.put(key, value) ;
            return true ;
        }
     }
    
}
                 
