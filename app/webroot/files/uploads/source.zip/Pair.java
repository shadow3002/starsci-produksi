public class Pair<F, S> {

    private F first ;
    private S second ;

    public Pair() {}

    public Pair( F st, S nd) {
       first = st ;
       second = nd ;
    }

    public F getFirst() {
       return first ;
    }

    public S getSecond() {
       return second ;
    }

    public void setFirst( F st ) {
       first = st ;
    }

    public void setSecond( S nd ) {
       second = nd ;
    }   
}