public class SANull implements SemanticAction {
    public SANull() {}
    
    public void execute( LexicalAnalyzer analyzer ) {}
}