import java.io.IOException;
import java.util.* ;
/*
Integer getCurrentLine() 
Map<String, String> getSymbolTable()
*/
public class LexicalAnalyzer {
    private Automat fsm ;
    private String input = null ;
    private Integer index = 0 ;
    private Integer currentLine = 1 ;
    
    private String token = null ;
    private String symbol = null ; 
    private SymbolTable symbols ;

    private String toPrint = "" ;
    
    public LexicalAnalyzer(Automat a, SymbolTable st) {
        symbols = st ;
        fsm = a ;
    }

    public void addOutput( String output ) {
        toPrint+= output + '\n' ;
    }
    
    public String getOutput() {
        return toPrint ;
    }
    
    public Integer getCurrentLine() {
        return currentLine ;
    }
     
    public boolean isEmpty() {
        return (index >= input.length()) ;
    }

    public void setInput( String in ) {
        input = in + '\n'; //se agrega un salto de linea para saber donde termina el archivo
    }

    private char getChar() {
        return input.charAt(index) ;
    }

    public void update() {
        if (!this.isEmpty()) {
            this.fsm.reset() ;
            updateToken(null) ;
            resetSymbol() ;
            char ch ;
            while (!this.fsm.finalState() && !this.isEmpty()) {
                ch = this.getChar() ;
                Object sa = fsm.next( ch ) ;  
                index++ ;
                setSymbol( ch ) ;
                if ( sa != null) {
                    ((SemanticAction)sa).execute(this) ;
                } else {
                    goBack() ; 
                    this.reportError("ERROR: Ilegal character '" + getSymbol() + "'" ) ;
                    this.update() ; 
                }
            }
        }
    }
    
    
    public boolean isReservedWord(String w){
        return (symbols.get(w) == "ReservedWord") ;
    }
    
    public String getToken() {
        return token  ;
    }


// ACTIONS
    public void setSymbol( char ch ) {
        symbol += ch ;
    }
    
    public String getSymbol(){
        return symbol ;
    }

    
    public void goBack(){
        this.skipChar() ;
        this.index-- ;
    }
    
    public void incCurrentLine() {
        currentLine++ ;
//        System.out.print( "\nLINE " + currentLine + ":"  );
    }
    
    public void reportError( String msj ) {
        System.out.println("[Line: " + currentLine + "] " + msj);
    }

	public void updateToken(String lastToken) {
		this.token = lastToken;
	}

    public void skipChar() {
        if (symbol.length() > 0 ) {
            symbol = symbol.substring(0, symbol.length()-1);
        }
    }
    
    public void skipPrevChar() {
        // EXAMPLE: skipChar("hola") --> "hoa"
        if (symbol.length() > 1 ) {
            char ch = symbol.charAt( symbol.length()-1 ) ;
            symbol = symbol.substring(0, symbol.length()-2);
            symbol += ch ;
        }
    }
    
    public void resetSymbol() {
        symbol = "" ;
    }
    
    public void setSymbol(String s) {
        symbol = s ;
    }
      
	
}