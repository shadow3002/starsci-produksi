// Constants declaration
// TODO
