
public interface SemanticAction {

    public void execute( LexicalAnalyzer analyzer ) ;

}