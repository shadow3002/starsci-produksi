public class SASkipChar implements SemanticAction {

    public SASkipChar() {}

    public void execute( LexicalAnalyzer analyzer ) {
        analyzer.skipChar() ;
    }
}